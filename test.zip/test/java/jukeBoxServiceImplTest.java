import org.niit.dao.impl.MusicImplDao;
import org.niit.model.SongPodcast;
import org.niit.service.searchservices.SongCatalog;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import static org.testng.Assert.assertNotEquals;
import static org.testng.AssertJUnit.assertEquals;

public class jukeBoxServiceImplTest {
    public static List<SongPodcast> songpodcastlist = new ArrayList<>();
    static List<SongCatalog> SongList = MusicImplDao.jukeBoxData();

    
    private static boolean True;

 // Search Song Test Case
    @Test
    public static void searchSongs() {
        Predicate<SongCatalog> songCatalogPredicate = p -> p.getAlbumName().equals("Believe");
        assertEquals(True, SongList.contains("Fix You"));
        assertEquals(9, SongList.size());
        assertNotEquals(8, SongList.size());
    }

// Search Podcast Test Case
    @Test
    public static void searchPodcast() {
        assertEquals(True, songpodcastlist.contains("Office Ladies"));
        assertEquals(0, songpodcastlist.size());
        assertNotEquals(5, songpodcastlist.size());

    }

    }



